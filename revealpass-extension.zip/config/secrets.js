// Automatically generated from .env. Do not edit directly.
export const SECRETS = {
  "EXTENSION_API_KEY": "dev_key_abc123xyz",
  "DEBUG_MODE": true
};
